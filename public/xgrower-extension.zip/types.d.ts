export interface ReplyTemplate {
    id: string;
    name: string;
    prompt: string;
    icon?: string;
}
export interface GenerateReplyRequest {
    tweetContent: string;
    template: ReplyTemplate;
    aboutMe?: string;
    context?: string;
}
export interface GenerateReplyResponse {
    reply: string;
    error?: string;
}
export interface AdvancedSettings {
    temperature: number;
    maxTokens: number;
    presencePenalty: number;
    frequencyPenalty: number;
    typingSpeed: number;
}
export interface PlatformSettings {
    systemPrompt: string;
    advancedSettings: AdvancedSettings;
    templates: ReplyTemplate[];
}
export interface StorageData {
    minimaxApiKey?: string;
    model?: string;
    xSettings?: PlatformSettings;
    templates?: ReplyTemplate[];
}
export interface ModelOption {
    id: string;
    name: string;
    provider: string;
    description?: string;
}
export declare const DEFAULT_X_TEMPLATES: ReplyTemplate[];
export declare const DEFAULT_ADVANCED_SETTINGS: AdvancedSettings;
export declare const DEFAULT_X_SETTINGS: Omit<PlatformSettings, 'systemPrompt'>;
export declare const MINIMAX_MODELS: ModelOption[];
//# sourceMappingURL=types.d.ts.map