export interface BurstConfig {
    keyword: string;
    count: number;
    templateName: string;
}
export interface BurstProgress {
    sent: number;
    total: number;
    state: 'idle' | 'searching' | 'picking-tweet' | 'reading' | 'opening-reply' | 'generating' | 'sending' | 'cooldown' | 'done' | 'error';
    message?: string;
}
type ProgressListener = (p: BurstProgress) => void;
export declare class BurstEngine {
    private aborted;
    private listener;
    private sent;
    private human;
    onProgress(fn: ProgressListener): void;
    abort(): void;
    run(config: BurstConfig, alreadySent?: number): Promise<void>;
    static searchUrlFor(keyword: string): string;
    private pickNextTweet;
    private clickReplyButtonOnTweet;
    /**
     * Find the template button injected by ChatterBox in the reply toolbar,
     * click it, and wait until text appears in the reply textarea.
     */
    private triggerTemplateAndWait;
    /**
     * Click X's Reply send button via Chrome DevTools Protocol so the
     * generated mouse event is `isTrusted=true` — synthetic JS clicks are
     * rejected by X's anti-bot React handler.
     */
    private clickSendReply;
    private isDisabled;
    private isVisible;
    private closeReplyModal;
    /**
     * Cooldown with intermittent scroll/mouse activity to fake idle browsing.
     */
    private humanCooldown;
    private emit;
}
export {};
//# sourceMappingURL=burst.d.ts.map