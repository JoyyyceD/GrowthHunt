declare const SUPABASE_URL = "https://xehgrzpbhhevodxflzwg.supabase.co";
declare const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhlaGdyenBiaGhldm9keGZsendnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg4Nzc1NjAsImV4cCI6MjA4NDQ1MzU2MH0.xmD7NBMDoDFYZ3RKL2XnGOMHkNnCzIrDHMPCFt4nwKk";
export declare const supabase: import("@supabase/supabase-js").SupabaseClient<any, "public", "public", any, any>;
export { SUPABASE_URL, SUPABASE_ANON_KEY };
//# sourceMappingURL=supabaseClient.d.ts.map