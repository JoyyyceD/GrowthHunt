import type { Session } from '@supabase/supabase-js';
export interface UserStatus {
    email: string;
    tier: 'free' | 'paid';
    proExpiresAt: string | null;
    dailyQuota: number;
    dailyUsed: number;
    dailyRemaining: number;
    monthlyQuota: number;
    monthlyUsed: number;
    monthlyRemaining: number;
}
export interface RedeemResult {
    ok: boolean;
    message: string;
    expiresAt: string;
}
export declare function loginWithEmail(email: string, password: string): Promise<void>;
export declare function signUpWithEmail(email: string, password: string): Promise<void>;
export declare function loginWithGoogle(): Promise<void>;
export declare function logout(): Promise<void>;
export declare function getSession(): Promise<Session | null>;
/**
 * Returns a valid access token, refreshing if needed.
 * Scans all chrome.storage.local keys to find the Supabase session,
 * avoiding hardcoded key names that differ across Supabase JS versions.
 */
export declare function getValidAccessToken(): Promise<string>;
export declare function getUserStatus(): Promise<UserStatus>;
export declare function redeemInviteCode(code: string): Promise<RedeemResult>;
export declare function sendPasswordReset(email: string): Promise<void>;
//# sourceMappingURL=auth.d.ts.map