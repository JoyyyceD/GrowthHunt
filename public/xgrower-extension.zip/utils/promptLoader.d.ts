/**
 * Loads the X/Twitter system prompt bundled with the extension.
 */
export declare function loadXSystemPrompt(): Promise<string>;
//# sourceMappingURL=promptLoader.d.ts.map